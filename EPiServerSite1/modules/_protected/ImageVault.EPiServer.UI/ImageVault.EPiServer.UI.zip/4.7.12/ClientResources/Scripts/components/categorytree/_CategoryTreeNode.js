require({cache:{
    'url:imagevault/components/categorytree/templates/_CategoryTreeNode.html': "<div class=\"dijitTreeNode epi-categoryTreeNode\" role=\"presentation\">\r\n    <a href=\"#\" tabIndex=\"-1\" data-dojo-attach-point=\"rowNode\" class=\"dijitTreeRow\" role=\"presentation\">\r\n        <div data-dojo-attach-point=\"indentNode\" class=\"dijitInline\"></div>\r\n       <span data-dojo-attach-point=\"contentNode\" class=\"dijitTreeContent\" role=\"presentation\">\r\n            <span data-dojo-attach-point=\"expandoNode\" class=\"dijitTreeExpando\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"expandoNodeText\" class=\"dijitExpandoText\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"iconNode\" class=\"dijitIcon dijitTreeIcon\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"labelNode\" class=\"dijitTreeLabel epi-categoryTreeLabel\" role=\"treeitem\"\r\n                tabindex=\"-1\" aria-selected=\"false\" data-dojo-attach-event=\"onclick:_onLabelClick, keyup:_onLabelKeyUp\">\r\n            </span>\r\n        </span>\r\n    </a>\r\n    <div data-dojo-attach-point=\"containerNode\" class=\"dijitTreeContainer\" role=\"presentation\" style=\"display: none;\"></div>\r\n</div>"
}
});
define("imagevault/components/categorytree/_CategoryTreeNode", [
    "epi",
    "dojo",
    "dojo/_base/declare",
	"dojo/dom-construct",
    "dijit/Tree",
    "dijit/form/CheckBox",
    "dijit/_TemplatedMixin",
    "dojo/text!./templates/_CategoryTreeNode.html",
    "epi-cms/widget/_ContentTreeNode"
],

function (epi, dojo, declare, domConstruct, Tree, CheckBox, _TemplatedMixin, template,_ContentTreeNode) {

    // _TreeNode is declared within Tree 
    return declare( [_ContentTreeNode, _TemplatedMixin], {
        // summary:
        //		A customized treenode for page tree
        //
        // description:
        //		Redefine template string. Use <a> tag to be able to drag in IE

        templateString: template,

        _checkbox: null,

        _selectedChildrenCount: 0,

        _item:null,

        constructor: function () {
            this._item = arguments[0].item;
        },
        postCreate: function () {
            // summary:
            //		Place checkbox into the tree node after node created.
            // tags:
            //		protected

            this.inherited(arguments);

            this._checkbox = this._createCheckbox(this._item);
        },

        _createCheckbox: function (item) {
            // summary:
            //		Create checkbox for the tree node.
            // tags:
            //		private

//            if (!item.selectable) {
//                return;
//            }
 			var container = domConstruct.create("span", {
                "class": "epi-checkboxNode dijitTreeExpando"
            });
            var checkbox = new CheckBox({
                name: "checkboxCategory",
                value: item.id,
                tabIndex: -1,
                onChange: dojo.hitch(this, function (isChecked) {
                    this.onCheckBoxChange(isChecked, item);
                }),
                checked: false
            });

            checkbox.placeAt(container);
            domConstruct.place(container, this.expandoNode, "after");

			return checkbox;
        },

        onCheckBoxChange: function (isChecked, item) {
            // summary:
            //      on checkbox clicked event.

        },

        _onLabelClick: function () {
            // summary:
            //		clicking the label toggles the checkbox
            // tags:
            //		private

            if (!this._checkbox) {
                return;
            }

            this._checkbox.setChecked(!this._checkbox.checked);
        },

        _onLabelKeyUp: function (evt) {
            // summary:
            //		pressing a key on the label toggles the checkbox
            // tags:
            //		private
            if (evt.keyCode == dojo.keys.SPACE || evt.keyCode == dojo.keys.ENTER) {
                this._onLabelClick();
            }
        },

        setCheckAttribute: function (checked) {
            // summary:
            //      Check/UnCheck the node.
            // tag
            //      public

            if (!this._checkbox) {
                return;
            }

            this._checkbox.set("checked", checked);
        },

        getCheckAttribute: function () {
            // summary:
            //      Returns the current checked status
            // tags:
            //      public
            
            if (!this._checkbox) {
                return false;
            }
            return this._checkbox.get("checked");
        },

        getSelectedChildrenCount: function () {
            //summary:
            //      get selected children count
            //tag:
            //      public

            return this._selectedChildrenCount;
        },

        setSelectedChildrenCount: function (value) {
            //summary:
            //      update the label with new selected children count
            //value:
            //      the value
            //tag:
            //      public

            this._selectedChildrenCount = value;
            this.updateLabel();
        },

        updateLabel: function () {
            //summary:
            //      update label of the tree node.
            //tag:
            //      public

            var originalLabel = this.tree.model.getLabel(this.item);

            if (this._selectedChildrenCount !== 0 && !this.isExpanded) {
                this.labelNode.innerHTML = originalLabel + "(" + this._selectedChildrenCount + ")";
            }
            else {
                this.labelNode.innerHTML = originalLabel;
            }
        }
    });
});
