﻿define([
// Dojo
    "dojo",
    "dojo/_base/declare",
    "dojo/html",
    "dojo/dnd/Source",
    "dojo/on",
//"dojo/i18n",
    "dojo/_base/lang",
    "dojo/_base/connect",
    "dojo/dom-style",
    "dojo/dom-attr",
    "dojox/widget/Standby",
// Dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",
    "dijit/form/TextBox",
    "dijit/form/Button",
    "dijit/form/DropDownButton",
    "dijit/TooltipDialog",
//CMS
    "epi-cms/_ContentContextMixin",
    "epi/routes",
    "epi/dependency",

//ImageVault
    "imagevault/components/BrowserGrid",
    "imagevault/_PropertyMediaMixin",
    "imagevault/components/categorytree/CategoryTree",
    "epi/i18n!epi/shell/ui/nls/imagevault.imagevaultbrowser"
], function (
// Dojo
    dojo,
    declare,
    html,
    dndSource,
    on,
//i18n,
    lang,
    connect,
    domStyle,
    domAttr,
    StandBy,
// Dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,
    TextBox,
    Button,
    DropDownButton,
    TooltipDialog,
//CMS
    _ContentContextMixin,
    routes,
    dependency,
//ImageVault
    browserGrid,
    _PropertyMediaMixin,
    Tree,
    res
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin, _PropertyMediaMixin], {
        templateString: '\
            <div class="iv-gadget-browser">\
                <form data-dojo-type="dijit/form/Form" dojoAttachPoint="form" style="padding:10px 10px 10px;">\
                    <div>\
                        <input type="text" name="query" data-dojo-attach-point="query" data-dojo-type="dijit/form/TextBox" data-dojo-props="class:&quot;iv-gadget-search&quot;"/>\
                        <div data-dojo-type="dijit/form/DropDownButton" data-dojo-attach-point="_categoriesButton">\
                          <span data-dojo-attach-point="categoryLabel">Categories</span>\
                          <div data-dojo-type="dijit/TooltipDialog" data-dojo-attach-point="_categoriesTreeDropDown" style="width:300px">\
                            <div data-dojo-attach-point="tree" data-dojo-type="imagevault/components/categorytree/CategoryTree" data-dojo-props="class:&quot;iv-gadget-categorytree&quot;"></div>\
                          </div>\
                        </div>\
                    </div>\
                </form>\
                <div data-dojo-type="imagevault/components/BrowserGrid" class="ivBrowserGrid" data-dojo-attach-point="grid" />\
                <div data-dojo-type="dojox/widget/Standby" data-dojo-attach-point="standby"/>\
            </div>',
        //Selected categories to filter by
        _selectedCategories: [],

        resources: res,

        startup: function () {

            if (this._started) {
                return;
            }
            //setup target of standby (needs to be done before the standby startup method itself is called
            this.standby.target = this.grid.id;
            //needs to hook up this manually (think it's an epi related issue)
            this._categoriesButton.dropDown = this._categoriesTreeDropDown;
            
            this.inherited(arguments);
            //show the standby to signal that we will load data
            this.standby.show();
            //load scripts and init data
            this.loadScripts().then(lang.hitch(this, function () {
                this.getSearchResults();
            }));
            var self = this;

            this.query.set("placeholder", this.resources.search);
            //update label on button for visual feedback...
            this._updateCategoriesButton();

            //Set category dropdown styles (allows vertical scrolling when tree is larger than dropdown)
            domStyle.set(this._categoriesTreeDropDown.containerNode, "overflow-x", "hidden");
            domStyle.set(this._categoriesTreeDropDown.containerNode, "overflow-y", "auto");

            //Prevent default behaviour for enter button...
            on(this.form, "submit", function (event) {
                self.getSearchResults();
                event.preventDefault();
                return false;
            });

            //HACK: Seems like IE does not register click events when component area is unpinned.
            on(this.query, "click", function () {
                self.query.focus();
            });
            on(this.grid.domNode, "loadingStarted", function () {
                self.standby.show();
            });
            on(this.grid.domNode, "loadingCompleted", function () {
                self.standby.hide();
            });
            on(this.grid.domNode, "error", function (event) {
                self.standby.hide();
//                console.log("error "+event.message);
            });
            this.connect(this.tree, 'onTreeNodeCheckBoxChange', dojo.hitch(this, this._onCategoryCheckBoxChange));
        },
        _onCategoryCheckBoxChange: function (isChecked, item) {
            //  Summary:
            //      Triggered when a checkbox in the tree is changed. 
            //      Update the parent-child relations and the local array of selected categories

            //local stored category
            var index = this._selectedCategories.indexOf(item.Id);
            var exists = index != -1;

            //node in the tree
            var treeNode = this.tree.getTreeNodeById(item.Id);
            if (treeNode == null) {
                return;
            }

            //category checked
            if (!exists && isChecked) {
                //add item
                this._selectedCategories.push(item.Id);

                //category unchecked
            } else if (exists && !isChecked) {
                //remove item
                this._selectedCategories.splice(index, 1);
            }
            this._updateCategoriesButton();
            this.getSearchResults();

        },
        _updateCategoriesButton: function () {
            //  summary:
            //      Updates the category button text.

            this._categoriesButton.set("label", this.resources.categories + " (" + this._selectedCategories.length + ")");
        },
        getSearchResults: function () {
            this.grid.fetchData({ query: this.query.get("value"), categories: this._selectedCategories });
        },

        restore: function () {
            // summary: Restore component visuals
            this.resize();
        },

        layout: function () {
            this.inherited(arguments);
            //set gridsize
            var height = this._contentBox.h - this.form.domNode.clientHeight;
            this.grid.resize({ h: height, w: this._contentBox.w });
            //set category dropdown size
            var catHeight = height - 10;
            if (catHeight < 30)
                catHeight = 30;
            domStyle.set(this._categoriesTreeDropDown.containerNode, "max-height", catHeight + "px");
            //this.grid.sizeChange();
        }

    });
});
