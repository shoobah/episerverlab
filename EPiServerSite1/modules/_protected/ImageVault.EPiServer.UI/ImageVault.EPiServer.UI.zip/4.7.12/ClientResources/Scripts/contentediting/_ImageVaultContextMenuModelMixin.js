﻿define([
// Dojo
"dojo/_base/declare"
],

function (
// Dojo
    declare
    ) {

    return declare(null, {
        modify: function (callback) {callback();},
        removeChild: function () { this.remove(); },
        //implement these in mixed in class
        remove: null,
        selectedItem: null
    });
});
