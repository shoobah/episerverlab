﻿define([
//dojo
    "dojo/dom-class",
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",
    "dojo/NodeList-manipulate",
    "dojo/aspect",
    "dojo/ready",
    "dojo/dnd/Manager",
    "dojo/on",
    "dojo/dom",
//dijit
    "dijit/_CssStateMixin",
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/TextBox",
    "dijit/focus",

//epi
    "epi/epi",
    "epi/shell/dnd/Source",
    "epi-cms/widget/_Droppable",
    "epi/dependency",
    "epi-cms/widget/_HasChildDialogMixin",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi-cms/_ContentContextMixin",

//imagevault
    "imagevault/_PropertyMediaMixin",
    "imagevault/_ErrorDisplayMixin",
//Requires that the ImageVault module is loaded (where we initiate our stores)
    "imagevault/RequireModule!ImageVault.EPiServer.UI",
    "epi/i18n!epi/shell/ui/nls/imagevaultepiservercms.propertymedialist"
],
function (
//dojo
    domClass,
    array,
    connect,
    declare,
    lang,
    Deferred,
    manipulate,
    aspect,
    ready,
    dndManager,
    on,
    dom,
//dijit
    _CssStateMixin,
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    TextBox,
    focusUtil,

//epi
    epi,
    source,
    _DroppableMixin,
    dependency,
    _HasChildDialogMixin,
	_ValueRequiredMixin,
    _ContentContextMixin,

//imagevault
    _PropertyMediaMixin,
    _ErrorDisplayMixin,
    appModule,
    res
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _CssStateMixin, _DroppableMixin, _PropertyMediaMixin, _ErrorDisplayMixin, _HasChildDialogMixin, _ValueRequiredMixin, _ContentContextMixin], {
        //dropAreaNode (from _Droppable) is selected using the data-dojo-attach-point="dropAreaNode" on the element that should be the target.
        //padding-top:25px is needed to not hide any error message bubble from the popup buttons
        templateString: '\
<div class="dijitInline" data-dojo-attach-point="dijitInline" style="padding-top:25px;margin-top:30px;width:100%">\
    <input type="hidden" data-dojo-attach-point="hiddenField" data-dojo-type="dijit/form/TextBox" />\
    <input type="hidden" data-dojo-attach-point="thumbnailHiddenField" data-dojo-type="dijit/form/TextBox" />\
    <ul class="propertymedialist" data-dojo-attach-point="propertyMediaList" style="display:inline-block; width:100%">\
        <li class="ui-state-disabled">\
            <span class="propertymedialist-thumbnail-container">\
                <img class="propertymedialist-thumbnail propertymedialist-thumbnail-add" src="" data-dojo-attach-point="propertyMediaListThumbnail" data-dojo-attach-event="onclick:_openImageVault" >\
            </span>\
        </li>\
    </ul>\
    <div class="propertymedia-button-row" data-dojo-attach-point="buttonRow">\
        <a data-dojo-attach-point="removeLink" class="propertymedia-btn propertymedia-remove" data-dojo-attach-event="onclick:_removeAll"><span>${resources.clearbuttontext}</span></a>\
        <a data-dojo-attach-point="insertLink, focusNode" class="propertymedia-btn" data-dojo-attach-event="onclick:_openImageVault">${resources.insert}</a>\
    </div>\
</div>',
        baseClass: "ivpml",
        thumb: "",
        propertyMediaScript: null,
        width: null,
        height: null,
        resizeMode: null,
        thumbEffect: null,
        thumbFormatId: null,
        thumbCache: { Thumb: { Url: "" } },
        mediaCacheItems: null,
        propertyMediaListObj: null,
        acceptDataTypes: ["ImageVaultMedia"],
        resources: res,

        postCreate: function () {
            // widget constructor uses a mixin which does not call set, so we do this ourselves to get the right value when the widget is created
            this._setValue(this.value, false);

            this.ErrorNode = this.dijitInline;
            //this handler will be notified when the callback to the propertyMediaList
            this._contextChangedHandler = connect.subscribe('/imagevault/propertymedialist', this, this._onContextChange);
            this._editHandler = connect.subscribe('/imagevault/propertymedialiststartedit', this, this._editImage);

            this.propertyMediaListThumbnail.id = this.hiddenField.id.replace('TextBox', 'thumbnail');
            this.propertyMediaList.id = this.hiddenField.id.replace('TextBox', 'pml');
            this.removeLink.id = this.hiddenField.id.replace('TextBox', 'removeLink');
            this.insertLink.id = this.hiddenField.id.replace('TextBox', 'insertLink');

            this._set("intermediateChanges", true);

            //Listen to all dnd events
            //this.subscribe("/dnd/start", function () { this._feedbackOnDrag(true); });
            //this.subscribe("/dnd/cancel", function () { this._feedbackOnDrag(false); });
            //this.subscribe("/dnd/drop", function () { this._feedbackOnDrag(false); });

            //Listen to ImageVault Window events
            this.subscribe("/imagevault/propertymediacommon/ivwinclosed", function (caller) {
                if (this.propertyMediaListObj === caller) {
                    this._ivWindowClosed();
                }
            });
            this.subscribe("/imagevault/propertymediacommon/ivwinopened", function (caller) {
                if (this.propertyMediaListObj === caller) {
                    this._ivWindowOpened();
                }
            });

            //setup the stores
            try {
                if (!this.store) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this.datastore = registry.get("imagevault.medialistpropertydatastore");
                }
            } catch (err) {
                this.ShowError("Error initializing store: " + err);
            }

            //load the scripts from the _PropertyMediaMixin 
            this.loadScripts().then(lang.hitch(this, function () {
                ready(lang.hitch(this, function () {
                    // get property settings from store
                    Deferred.when(this.datastore.query({ contextId: this.getCurrentContext().id, propertyName: this.fullName, width: this.width, height: this.height, resizeMode: this.resizeMode, mode: this.getCurrentContext().currentMode }), lang.hitch(this, function (storeResponse) {
                        if (storeResponse.ErrorCode) {
                            // something went wrong
                            this.ShowError("Error in store:" + storeResponse.ErrorMessage);
                            return;
                        }
                        this.thumbFormatId = storeResponse.ThumbFormatId;
                        this.thumbEffect = storeResponse.ThumbEffects;
                        this.thumbCache = storeResponse.ThumbCache;
                        this.thumb = storeResponse.Thumb;

                        // set hiddenfield and mediaCache
                        if (this.thumbCache) {
                            this.thumbnailHiddenField.set("value", this.thumbCache);
                            this.mediaCacheItems = JSON.parse(this.thumbCache);
                        }

                        // set mediareference
                        if (storeResponse.MediaReference) {
                            this.hiddenField.set("value", storeResponse.MediaReference);
                        }

                        // Set thumbnail url in template
                        this.propertyMediaListThumbnail.setAttribute("src", this.thumb);

                        // then init the component
                        this.initPropertyMediaList();
                    }));
                }));
            }));

            // call base implementation
            //this.inherited(arguments);    // calling inherited here hangs EPi 7


        },
        initPropertyMediaList: function () {
            this.propertyMediaListObj = new ImageVault.PropertyMediaList({
                hiddenFieldId: this.hiddenField.id,
                thumbnailHiddenFieldId: this.thumbnailHiddenField.id,
                mediaListId: this.propertyMediaList.id,
                defaultThumbnailId: this.propertyMediaListThumbnail.id,
                removeLinkId: this.removeLink.id,
                thumbnailFormatId: this.thumbFormatId,
                inserLinkId: this.insertLink.id,
                targetWidth: this.width,
                targetHeight: this.height,
                resizeMode: this.resizeMode,
                propertyThumbnailWidth: this.thumbEffect[0].Width,
                propertyThumbnailHeight: this.thumbEffect[0].Height,
                propertyThumbnailResizeMode: this.thumbEffect[0].ResizeMode,
                readOnly: this.readOnly
            });

            // Render the list items
            for (var i = 0; i < this.mediaCacheItems.length; i++) {
                this.propertyMediaListObj.RenderListItem(this.mediaCacheItems[i]);
            }

            this._centerEmptyThumbnail();
            this.propertyMediaListObj.UpdateUi();
        },
        _centerEmptyThumbnail: function () {
            var parentHeight = this.thumbEffect[0].Height;
            var elementHeight = this.propertyMediaListThumbnail.height;

            // IE
            if (!elementHeight || elementHeight == 0) {
                elementHeight = 31;
            }

            $("#" + this.propertyMediaListThumbnail.id).css("margin-top", Math.floor((parentHeight - elementHeight) / 2) + "px");
        },
        _onContextChange: function (pml) {
            if (this.readOnly)
                return;

            //check if event is for us.
            if (this.propertyMediaListObj !== pml)
                return;

            this._set("isShowingChildDialog", false);
            // Widget will update itself using the new context.
            var mediaReference = this.propertyMediaListObj.getHiddenFieldValue();
            this._setValue(mediaReference, false);

            // EPi autosave triggers when focus leaves the property.
            // force de-focus to aid in autosave issues
            focusUtil.focus(this.domNode);
            focusUtil.focus(this.ownerDocumentBody);
        },
        _openImageVault: function () {
            if (this.readOnly)
                return;

            // make sure we have the focus
            focusUtil.focus(this.domNode);
        },

        _removeAll: function () {
            focusUtil.focus(this.domNode);
        },

        // Set this objects state when the window is opened.
        _ivWindowOpened: function () {
            this._set("isShowingChildDialog", true);
        },

        // Reset this objects state when the window is closed.
        _ivWindowClosed: function () {
            this._set("isShowingChildDialog", false);
        },
        isValid: function () {
            // summary:
            //    Check if widget's value is valid.
            // tags:
            //    protected, override
            // 2014-03-11/RW: Since the value also may be be an empty object,
            //	make sure to verify this scenario as well.
            var value = this.value;
            if (typeof (this.value) === "object") {
                value = JSON.stringify(this.value);
            }
            return !this.required || this.value && value != "[]";
        },

        // Setter for value property
        _setValueAttr: function (value) {
            if (!this.propertyMediaListObj || this.readOnly)
                return;

            this._set("value", value);
        },
        _setReadOnlyAttr: function (value) {
            this._set("readOnly", value);
        },
        // Event handler for InsertLink
        _editImage: function () {
            if (this.readOnly)
                return;
            this._set("isShowingChildDialog", true);
        },
        validate: function () {
            return this.inherited(arguments);
        },

        _setValue: function (value, updateFields) {

            var mediaReference = value;
            var mediaReferenceString = value;

            if (value === null || typeof (value) === "undefined" || value === "") {
                mediaReference = [];
                mediaReferenceString = "[]";

            } else if (typeof (value) === "string") {
                mediaReference = JSON.parse(value);

            } else if (typeof (value) === "object") {
                //needs to fix any non parsed json strings.(epi returns a mix of objects and strings)
                if (value && value.length) {
                    for (var i = 0; i < value.length; i++) {
                        var item = value[i];
                        if (item && typeof (item) === "string") {
                            value[i] = JSON.parse(item);
                        }
                    }
                }
                //need to create new js object (problem with ie)
                mediaReference = value;
                mediaReferenceString = JSON.stringify(value);
            }
            if (updateFields) {
                this.hiddenField.set("value", mediaReferenceString == null ? "[]" : mediaReferenceString);
                // update the UI when we change hiddenField and the propertyMediaListObj is initialized (occurs when the forms-edit page is loaded)
                if (this.propertyMediaListObj) {
                    this.propertyMediaListObj.UpdateUi();
                }
            }
            var val = mediaReference == null ? [] : mediaReference;
            this.set("value", val);

            // Reset the state property before validation
            this._set("state", undefined);
        }
    });
});
